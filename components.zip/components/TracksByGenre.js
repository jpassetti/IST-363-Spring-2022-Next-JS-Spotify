import { useState } from 'react'

import Tabs from './Tabs'
import Tracks from './Tracks'

const genres = [
	"Rock", "Country", "Hip-hop", "All"
];

const TracksByGenre = () => {
	const [activeGenre, setActiveGenre] = useState("Rock");

	return <div>
		<h2>Top Songs by Genre</h2>
		<Tabs 
			items={genres} 
			activeItem={activeGenre} 
			clickHandler={setActiveGenre}
		/>
		<Tracks />
	</div>
}
export default TracksByGenre;
