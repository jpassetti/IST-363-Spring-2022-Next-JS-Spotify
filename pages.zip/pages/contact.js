export default function ContactPage() {
	return <h1>Contact</h1>
}
