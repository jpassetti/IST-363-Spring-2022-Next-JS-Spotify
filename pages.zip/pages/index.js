import Head from 'next/head'
import Link from 'next/link'
import Image from 'next/image'

// custom components
import Button from '../components/Button'
import Layout from '../components/Layout'
import TracksByGenre from '../components/TracksByGenre'

export default function Home() {
  return (
    <Layout>
      <Head>
        <title>Creeeeeeeeeeeate Next App</title>
        <link rel="icon" href="/favicon.ico" />
		<meta name="description" content="This is a summary of my website"/>
      </Head>

      <main>
		<Image 
			src="/images/profile.jpg"
			width={200}
			height={200}
			alt="Jeff Passetti"
		/>
        <h1 className="title">
			<Link href="/posts/first-post">
				<a>Firrrrrrrrrst post</a>
			</Link>
        </h1>

        <p className="description">
          Get started by editing <code>pages/index.js</code>
        </p>

		<Button 
			label="Register now"
			path="/posts/first-post"
			type="primary" 
		/>
		<Button 
			label="Download now" 
			path="/download"
			type="secondary"
		/>

		<TracksByGenre />
	
      </main>

      <footer>
		IST 363 Spotify prototype.
      </footer>
    </Layout>
  )
}
